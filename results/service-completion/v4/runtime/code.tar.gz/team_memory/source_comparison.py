"""Select supplied source/sentence IDs; resolve exact quotes in code.

Uses NLTK's existing Punkt segmentation and the same source-ID citation boundary
as the vendored LangChain schema. No new classifier or extra model call. The
legacy timeline quote API remains available for historical replay.
"""
from copy import deepcopy
import json
from . import timeline

# Retain the evaluated timeline comparison policy. Only its quotation output
# representation changes; do not replace the decision policy with a shorter one.
PROMPT = timeline.COMPARE.split('\nReturn ',1)[0] + r'''
Each source contains numbered ORIGINAL sentences. Select IDs instead of copying
or rephrasing text. Return one JSON object:
{"relations":[{"kind":"reconsider|coexist|conflict|correction","target":"earlier source ID",
"old_sentence_ids":[0],"new_sentence_ids":[0],
"reason":"explain the specific old claim or decision, new observation, and relevant condition"}]}.
Use the actual kind word, not the alternatives. At most four relations, one per
kind and target. Select one or more consecutive sentence IDs from each source.
For reconsider cite the actual earlier decision AND its rationale/conditions when
present. For coexist cite comparable observations under different conditions.
For conflict cite incompatible claims under the same conditions. For correction
cite the precise old assertion and the explicit retraction/correction.
For correction ONLY, also supply old_assertion_id and new_assertion_id: the one
changed-fact sentence inside each selected context, excluding unchanged facts
such as an owner or another setting. Other kinds do not have assertion fields.
Only cite supplied earlier source IDs. Each proposed action goes to the earlier
source owner for review; proposing is not approval. Coexist is informational and
does not change established facts or require an approval request.
Coexist is not a generic label for unrelated facts. If the incoming report
explicitly preserves the old blocking premise and supplies no comparable
conflicting measurement, return no relation. If nothing changes, return
{"relations":[]}.
'''

def compare_sources(generate, content):
    observed = {}
    def recorded(system, request):
        observed['raw'] = generate(system, request)
        return observed['raw']
    try:
        return _compare_sources(recorded, content)
    except (ValueError,KeyError,TypeError) as exc:
        if 'raw' not in observed:
            raise
        # Let timeline persist a failed receipt instead of retrying the same
        # invalid selector on every subsequent ask/sync. Keep actual output.
        return json.dumps(dict(relations=None,selection_error=type(exc).__name__+': '+str(exc),
                               model_output=observed['raw']),ensure_ascii=False)


def _compare_sources(generate, content):
    from nltk.tokenize import PunktTokenizer
    original=json.loads(content);data=deepcopy(original);spans={};sources={}
    incoming=original['incoming']['id']
    for env in data['earlier']+[data['incoming']]:
        sid=env['id'];text=env['source'].pop('text')
        bounds=list(PunktTokenizer('english').span_tokenize(text))
        if not bounds and text.strip():bounds=[(0,len(text))]
        spans[sid]=bounds;sources[sid]=text
        env['source']['sentences']=[dict(id=i,text=text[a:b]) for i,(a,b) in enumerate(bounds)]
    raw=generate(PROMPT,json.dumps(data,ensure_ascii=False))
    parsed=timeline.decode(raw)
    rows=parsed['relations']
    if not isinstance(rows,list) or len(rows)>4:raise ValueError('At most four source relations')
    def quote(sid,indices):
        if not isinstance(indices,list) or not indices or any(type(i) is not int for i in indices):
            raise ValueError('Sentence IDs must be a nonempty integer list')
        if indices!=list(range(indices[0],indices[-1]+1)) or indices[0]<0 or indices[-1]>=len(spans[sid]):
            raise ValueError('Sentence IDs must be consecutive and in range')
        return sources[sid][spans[sid][indices[0]][0]:spans[sid][indices[-1]][1]]
    mapped=[];informational=[]
    for row in rows:
        target=row['target']
        if target not in sources or target==incoming:raise ValueError('Unknown earlier source ID')
        old_ids,new_ids=row['old_sentence_ids'],row['new_sentence_ids']
        item=dict(kind=row['kind'],target=target,old_quote=quote(target,old_ids),
                  new_quote=quote(incoming,new_ids),reason=row['reason'])
        if item['kind']=='correction':
            a,b=row['old_assertion_id'],row['new_assertion_id']
            if type(a) is not int or type(b) is not int or a not in old_ids or b not in new_ids:
                raise ValueError('Changed assertion ID must belong to its context')
            item.update(old_assertion=quote(target,[a]),new_assertion=quote(incoming,[b]))
        if item['kind']=='coexist':informational.append(item)
        else:mapped.append(item)
    return json.dumps(dict(relations=mapped,informational_relations=informational),ensure_ascii=False)
